<?php 
function orange_movers_custom_css(){
	global $orange;
	
	if(!is_admin()) :
	?>
  
	<?php 
	
		$orange_theme_color						 = '';
		$orange_menu_text_color						 = '';
		$orange_menu_text_hover_acive_color						 = '';
		$orange_sticky_menu_bg_color						 = '';
		$orange_sticky_menu_text_color						 = '';
		$orange_sticky_menu_text_hover_acive_color						 = '';
		$orange_banner_bg_color						 = '';
		$orange_banner_text_color						 = '';
		$orange_footer_text_color						 = '';
		$orange_spinner_bg_color						 = '';
		$orange_spinner_main_color						 = '';
		$orange_css_editor						 = '';
		

		if ( isset( $orange['orange_theme_color'] ) ) {
			$orange_theme_color = $orange['orange_theme_color'];
		}	
		if ( isset( $orange['orange_menu_text_color'] ) ) {
			$orange_menu_text_color = $orange['orange_menu_text_color'];
		}		
		if ( isset( $orange['orange_menu_text_hover_acive_color'] ) ) {
			$orange_menu_text_hover_acive_color = $orange['orange_menu_text_hover_acive_color'];
		}			
		if ( isset( $orange['orange_sticky_menu_bg_color'] ) ) {
			$orange_sticky_menu_bg_color = $orange['orange_sticky_menu_bg_color'];
		}			
		
		if ( isset( $orange['orange_sticky_menu_text_color'] ) ) {
			$orange_sticky_menu_text_color = $orange['orange_sticky_menu_text_color'];
		}			
		if ( isset( $orange['orange_sticky_menu_text_hover_acive_color'] ) ) {
			$orange_sticky_menu_text_hover_acive_color = $orange['orange_sticky_menu_text_hover_acive_color'];
		}			
		
		if ( isset( $orange['orange_banner_bg_color'] ) ) {
			$orange_banner_bg_color = $orange['orange_banner_bg_color'];
		}	
		
		if ( isset( $orange['orange_banner_text_color'] ) ) {
			$orange_banner_text_color = $orange['orange_banner_text_color'];
		}	
				
		
		if ( isset( $orange['orange_footer_text_color'] ) ) {
			$orange_footer_text_color = $orange['orange_footer_text_color'];
		}	
		

		if ( isset( $orange['orange_spinner_bg_color'] ) ) {
			$orange_spinner_bg_color = $orange['orange_spinner_bg_color'];
		}			
		
		if ( isset( $orange['orange_spinner_main_color'] ) ) {
			$orange_spinner_main_color = $orange['orange_spinner_main_color'];
		}			

	
		if ( isset( $orange['orange_css_editor'] ) ) {
			$orange_css_editor = $orange['orange_css_editor'];
		}
	

	wp_enqueue_style( 'orange-custom-css', get_template_directory_uri() . '/assets/css/custom-style.css' );
	
	//add custom css
	$orange_custom_css = "

		body .preloader {
			background: {$orange_spinner_bg_color};
		}			
		
		.status .status-mes{

			border-top-color: {$orange_spinner_main_color};
			border-right-color: {$orange_spinner_main_color};
			border-bottom-color: {$orange_spinner_main_color};
		}			
		
			
		
		.navbar-default .navbar-nav > li > a {
			color: {$orange_menu_text_color} !important;
		}		
		
		.navbar-default .navbar-nav > li > a:focus, 
		.navbar-default .navbar-nav > li > a:hover{
			color: {$orange_menu_text_hover_acive_color} !important;
		}		

		.navbar-default.menu-shrink{
			background: {$orange_sticky_menu_bg_color} !important;
		}		
		.menu-top.menu-shrink li a {
			color: {$orange_sticky_menu_text_color}!important;
		}	
		.menu-top.menu-shrink li a:hover {
			color: {$orange_sticky_menu_text_hover_acive_color}!important;
		}		
		
		.section-padding.bg_color_title{
			background: {$orange_banner_bg_color};
			color: {$orange_banner_text_color};
		}	

		.section-padding.bg_color_title .section-blog-title{
			color: {$orange_banner_text_color};
		}
		
		
		.contact-address .footer_copyright p,
		.contact-address .address h1,
		.contact-address .address h2,
		.contact-address .address h3{
			color: {$orange_footer_text_color};
		}			
		
			
	.section-title span,
	.our-team .social li a,
	.our-team .icon,
	.owl-carousel.owl-theme .owl-controls .owl-page span,
	.box::after,
	body .pricingTable:after,
	.newsletter_form_border{
		background: {$orange_theme_color}!important;
	}
	a:hover,
	.serviceBox:hover .service-icon{   
		color: {$orange_theme_color}!important;
	}
	.serviceBox:hover:after,
	.pricingTable .price-value,
	body .contact input:hover, 
	body .contact input:focus,
	body .contact textarea:hover,
	body .contact textarea:focus {
		border-color: {$orange_theme_color}!important;
	}
	body .btn-promotion-bg,
	body .single_service > i,
	.recent-projects .portfolio-filters li.active,
	.recent-projects .portfolio-filters li:hover,
	body .btn-contact-bg,
	body .btn-newsletter-bg,
	body .topcontrol{
		background: {$orange_theme_color};
		border-color: {$orange_theme_color};
	}
	
	";
	
	//Add the above custom CSS via wp_add_inline_style
	wp_add_inline_style( 'orange-custom-css', $orange_custom_css ); //Pass the variable into the main style sheet ID
	
	
  endif;
}

add_action( 'wp_enqueue_scripts', 'orange_movers_custom_css'  ) ;