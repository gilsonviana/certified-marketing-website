<?php


add_action( 'cmb2_init', 'orange_metabox_options' );

function orange_metabox_options(){
	// Start with an underscore to hide fields from custom fields list
	$prefix = '_orange_';

	// Global Options
		
	$cmb2_global_opt = new_cmb2_box( array(
		'id'           => $prefix . 'global_options',
		'title'        => esc_html__( 'Options', 'orange' ),
		'object_types' => array( 'post' , 'page'), // Post type
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left
		//'show_on'      => array( 'id' => array( 2, ) ), // Specific post IDs to display this metabox
	) );
	
	$cmb2_global_opt->add_field( array(
	    'name'             => esc_html__('Banner Image' , 'orange'),
	    'id'               => $prefix .'banner_img',
	    'desc'             => esc_html__( 'upload banner image here','orange' ),
		'type'             => 'file',

	) );	
	
	// Post Options
		
	$cmb2_post_opt = new_cmb2_box( array(
		'id'           => $prefix . 'post_options',
		'title'        => esc_html__( 'Post Type Options', 'orange' ),
		'object_types' => array( 'post'), // Post type
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left
		//'show_on'      => array( 'id' => array( 2, ) ), // Specific post IDs to display this metabox
	) );
	
	$cmb2_post_opt->add_field( array(
	    'name'             => esc_html__('Enter Embed Code' , 'orange'),
	    'id'               => $prefix .'embed_code',
	    'desc'             => esc_html__( 'enter embed code here','orange' ),
		'type'             => 'textarea_code',

	) );	
	
	//About
	$cmb2_about = new_cmb2_box( array(
		'id'           => $prefix . 'about_options',
		'title'        => esc_html__( 'About Info', 'orange' ),
		'object_types' => array( 'about'), // Post type
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left
		//'show_on'      => array( 'id' => array( 2, ) ), // Specific post IDs to display this metabox
	) );

	$cmb2_about->add_field( array(
	    'name'             => esc_html__('Icon' , 'orange'),
	    'id'               => $prefix .'about_icon',
	    'desc'             => esc_html__( 'enter about icon here','orange' ),
		'type'             => 'text',
		'default'    => 'fa fa-anchor',
	) );
	
	// Team
	$cmb2_team = new_cmb2_box( array(
		'id'           => $prefix . 'team_options',
		'title'        => esc_html__( 'Team Info', 'orange' ),
		'object_types' => array( 'team'), // Post type
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left
		//'show_on'      => array( 'id' => array( 2, ) ), // Specific post IDs to display this metabox
	) );

	$cmb2_team->add_field( array(
	    'name'             => esc_html__('Designation' , 'orange'),
	    'id'               => $prefix .'team_designation',
	    'desc'             => esc_html__( 'eneter Designation here','orange' ),
		'type'             => 'text',
		'default'    => 'Web Developer',
	) );

	$team_group_field_id = $cmb2_team->add_field( array(
		'id'          => $prefix .'team_group_field_opt',
		'type'        => 'group',
		// 'repeatable'  => false, // use false if you want non-repeatable group
		'options'     => array(
			'group_title'   => esc_html__( 'Social  {#}', 'orange' ), // since version 1.1.4, {#} gets replaced by row number
			'add_button'    => esc_html__( 'Add New Social', 'orange' ),
			'remove_button' => esc_html__( 'Remove Social', 'orange' ),
			'sortable'      => true, // beta
			// 'closed'     => true, // true to have the groups closed by default
		),
	) );

	// Id's for group's fields only need to be unique for the group. Prefix is not needed.
	$cmb2_team->add_group_field( $team_group_field_id, array(
		'name' => esc_html__('Social Icon' , 'orange'),
		'id'   => $prefix .'team_social_icon',
		'type' => 'text',
		'default' => 'ti-facebook',
		'description' => esc_html__('write icon here' , 'orange'),
		// 'repeatable' => true, // Repeatable fields are supported w/in repeatable groups (for most types)
	) );
	
	// Id's for group's fields only need to be unique for the group. Prefix is not needed.
	$cmb2_team->add_group_field( $team_group_field_id, array(
		'name'             => esc_html__('Social Link' , 'orange'),
		'id'               => $prefix .'team_social_link',
		'type' => 'text',
		'default' => '#',
		'desc'             => esc_html__( 'enter url here','orange' ),
		// 'repeatable' => true, // Repeatable fields are supported w/in repeatable groups (for most types)
	) );	
	
	// Process
	$cmb2_process = new_cmb2_box( array(
		'id'           => $prefix . 'process_options',
		'title'        => esc_html__( 'Process Info', 'orange' ),
		'object_types' => array( 'process'), // Post type
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left
		//'show_on'      => array( 'id' => array( 2, ) ), // Specific post IDs to display this metabox
	) );

	$cmb2_process->add_field( array(
	    'name'             => esc_html__('Icon' , 'orange'),
	    'id'               => $prefix .'process_icon',
	    'desc'             => esc_html__( 'enter Icon Name here','orange' ),
		'type'             => 'text',
		'default'    => 'fa fa-long-arrow-right',
	) );
	
	$process_group_field_id = $cmb2_process->add_field( array(
		'id'          => $prefix .'process_group_field_opt',
		'type'        => 'group',
		// 'repeatable'  => false, // use false if you want non-repeatable group
		'options'     => array(
			'group_title'   => esc_html__( 'Feature  {#}', 'orange' ), // since version 1.1.4, {#} gets replaced by row number
			'add_button'    => esc_html__( 'Add New Feature', 'orange' ),
			'remove_button' => esc_html__( 'Remove Feature', 'orange' ),
			'sortable'      => true, // beta
			// 'closed'     => true, // true to have the groups closed by default
		),
	) );

	// Id's for group's fields only need to be unique for the group. Prefix is not needed.
	$cmb2_process->add_group_field( $process_group_field_id, array(
		'name' => esc_html__('Icon' , 'orange'),
		'id'   => $prefix .'process_list_icon',
		'type' => 'text',
		'default' => 'fa fa-long-arrow-right',
		'description' => esc_html__('enter text here' , 'orange'),
		// 'repeatable' => true, // Repeatable fields are supported w/in repeatable groups (for most types)
	) );
	
	// Id's for group's fields only need to be unique for the group. Prefix is not needed.
	$cmb2_process->add_group_field( $process_group_field_id, array(
		'name' => esc_html__('List' , 'orange'),
		'id'   => $prefix .'process_text',
		'type' => 'text',
		'default' => 'Client interview',
		'description' => esc_html__('enter text here' , 'orange'),
		// 'repeatable' => true, // Repeatable fields are supported w/in repeatable groups (for most types)
	) );
	
	
	//Project
	$cmb2_project = new_cmb2_box( array(
		'id'           => $prefix . 'project_options',
		'title'        => esc_html__( 'Project Info', 'orange' ),
		'object_types' => array( 'project'), // Post type
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left
		//'show_on'      => array( 'id' => array( 2, ) ), // Specific post IDs to display this metabox
	) );

	$cmb2_project->add_field( array(
	    'name'             => esc_html__('Project SubTitle' , 'orange'),
	    'id'               => $prefix .'project_sub_title',
	    'desc'             => esc_html__( 'enter text here','orange' ),
		'type'             => 'text',
		'default'    => 'project subtitle here',
	) );
	
	$cmb2_project->add_field( array(
	    'name'             => esc_html__('Project Details Title' , 'orange'),
	    'id'               => $prefix .'project_details_title',
	    'desc'             => esc_html__( 'enter text here','orange' ),
		'type'             => 'text',
		'default'    => 'Project Overview',
	) );
	
	$cmb2_project->add_field( array(
	    'name'             => esc_html__('Project Client Label' , 'orange'),
	    'id'               => $prefix .'project_client_label',
	    'desc'             => esc_html__( 'enter text here','orange' ),
		'type'             => 'text',
		'default'    => 'Client :',
	) );	
	
	$cmb2_project->add_field( array(
	    'name'             => esc_html__('Project Client' , 'orange'),
	    'id'               => $prefix .'project_client',
	    'desc'             => esc_html__( 'enter text here','orange' ),
		'type'             => 'text',
		'default'    => 'Wrapbootstrap',
	) );	
	
	$cmb2_project->add_field( array(
	    'name'             => esc_html__('Project Date Label' , 'orange'),
	    'id'               => $prefix .'project_date_label',
	    'desc'             => esc_html__( 'enter text here','orange' ),
		'type'             => 'text',
		'default'    => 'Date :',
	) );	
	
	$cmb2_project->add_field( array(
	    'name'             => esc_html__('Project Date' , 'orange'),
	    'id'               => $prefix .'project_date',
	    'desc'             => esc_html__( 'enter text here','orange' ),
		'type'             => 'text',
		'default'    => ' 12 october 2017',
	) );	
	
	$cmb2_project->add_field( array(
	    'name'             => esc_html__('Project Url Label' , 'orange'),
	    'id'               => $prefix .'project_url_label',
	    'desc'             => esc_html__( 'enter text here','orange' ),
		'type'             => 'text',
		'default'    => 'Project Url :',
	) );	
	
	$cmb2_project->add_field( array(
	    'name'             => esc_html__('Project Url' , 'orange'),
	    'id'               => $prefix .'project_url',
	    'desc'             => esc_html__( 'enter text here','orange' ),
		'type'             => 'text',
		'default'    => 'www.wrapbootstrap.net',
	) );	
	
	//Project
	$cmb2_portfolio = new_cmb2_box( array(
		'id'           => $prefix . 'portfolio_options',
		'title'        => esc_html__( 'Portfolio Info', 'orange' ),
		'object_types' => array( 'work'), // Post type
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left
		//'show_on'      => array( 'id' => array( 2, ) ), // Specific post IDs to display this metabox
	) );

	$cmb2_portfolio->add_field( array(
	    'name'             => esc_html__('Portfolio SubTitle' , 'orange'),
	    'id'               => $prefix .'portfolio_sub_title',
	    'desc'             => esc_html__( 'enter text here','orange' ),
		'type'             => 'text',
		'default'    => 'portfolio sub title ',
	) );
	

	
	// Pricing
	$cmb2_pricing = new_cmb2_box( array(
		'id'           => $prefix . 'pricing_options',
		'title'        => esc_html__( 'Pricing Info', 'orange' ),
		'object_types' => array( 'pricing'), // Post type
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left
		//'show_on'      => array( 'id' => array( 2, ) ), // Specific post IDs to display this metabox
	) );
	
	$cmb2_pricing->add_field( array(
	    'name'             => esc_html__('Feature' , 'orange'),
	    'id'               => $prefix .'pricing_feat',
	    'desc'             => esc_html__( 'select pricing here','orange' ),
		'type'             => 'checkbox',

	) );
	
	$cmb2_pricing->add_field( array(
	    'name'             => esc_html__('Price' , 'orange'),
	    'id'               => $prefix .'pricing_price',
	    'desc'             => esc_html__( 'enter icon name here','orange' ),
		'type'             => 'text',
		'default'    => '$10',
	) );

	$pricing_group_field_id = $cmb2_pricing->add_field( array(
		'id'          => $prefix .'pricing_group_field_opt',
		'type'        => 'group',
		// 'repeatable'  => false, // use false if you want non-repeatable group
		'options'     => array(
			'group_title'   => esc_html__( 'Feature  {#}', 'orange' ), // since version 1.1.4, {#} gets replaced by row number
			'add_button'    => esc_html__( 'Add New Feature', 'orange' ),
			'remove_button' => esc_html__( 'Remove Feature', 'orange' ),
			'sortable'      => true, // beta
			// 'closed'     => true, // true to have the groups closed by default
		),
	) );

	// Id's for group's fields only need to be unique for the group. Prefix is not needed.
	$cmb2_pricing->add_group_field( $pricing_group_field_id, array(
		'name' => esc_html__('Feature' , 'orange'),
		'id'   => $prefix .'pricing_feature',
		'type' => 'text',
		'description' => esc_html__('enter text here' , 'orange'),
		// 'repeatable' => true, // Repeatable fields are supported w/in repeatable groups (for most types)
	) );
	
	$cmb2_pricing->add_field( array(
	    'name'             => esc_html__('Button Text' , 'orange'),
	    'id'               => $prefix .'pricing_btn_text',
	    'desc'             => esc_html__( 'enter text here','orange' ),
		'type'             => 'text',
		'default'    => 'Sign Up',
	) );		
	
	$cmb2_pricing->add_field( array(
	    'name'             => esc_html__('Button Link' , 'orange'),
	    'id'               => $prefix .'pricing_btn_link',
	    'desc'             => esc_html__( 'enter link here','orange' ),
		'type'             => 'text',
		'default'    => '#',
	) );	

	// Testimonials
	$cmb2_testimonials = new_cmb2_box( array(
		'id'           => $prefix . 'testimonials_options',
		'title'        => esc_html__( 'Testimonials Info', 'orange' ),
		'object_types' => array( 'testimonials'), // Post type
		'context'      => 'normal',
		'priority'     => 'high',
		'show_names'   => true, // Show field names on the left
		//'show_on'      => array( 'id' => array( 2, ) ), // Specific post IDs to display this metabox
	) );

	$cmb2_testimonials->add_field( array(
	    'name'             => esc_html__('Designation' , 'orange'),
	    'id'               => $prefix .'testimonials_designation',
	    'desc'             => esc_html__( 'enter Designation here','orange' ),
		'type'             => 'text',
		'default'    => 'Web Developer',
	) );

	
}