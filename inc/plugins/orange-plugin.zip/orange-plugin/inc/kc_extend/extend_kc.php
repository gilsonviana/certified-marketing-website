<?php

 
add_action('init', 'orange_kc_active', 99 );
 
function orange_kc_active() {
 
	if (function_exists('kc_add_map')) 
	{ 
	    kc_add_map(
	        array(

	            'shortcode_importer' => array(
	                'name' => esc_html__('Shortcode Importer', 'orange'),
	                'icon' => 'kc-icon-progress',
	                'category' => 'Orange Shortcodes',
	                'params' => array(
	                
	                    array(
							'name' => 'enter_shortcode',
							'label' => esc_html__( 'Enter Shortcode', 'orange' ),
							'type' => 'textarea',
							'admin_label' => true,
						),	    	                             

	                )
	            ),  // End of elemnt kc_icon 

	        ) 
			
	    ); // End add map	 	   
		
		kc_add_map(
	        array(

	            'banner_area' => array(
				'name' => esc_html__('Banner Area', 'orange'),
				'icon' => 'kc-icon-progress',
				'category' => 'Orange Shortcodes',
				'css_box' => true,
				'params' => array(	
				
				
					array(
						'name' => 'ripple_opt',
						'label' => esc_html__( 'Ripple Option', 'orange' ),
						'type' => 'radio',
						'options' => array(
							'1' => 'Show',
							'2' => 'Hide',
						),
					),	
					
					array(
						'name' => 'sec_bg_img',
						'label' => esc_html__( 'Background Image', 'orange' ),
						'type' => 'attach_image',
					),			

					array(
						'name' => 'sec_title',
						'label' => esc_html__( 'Title', 'orange' ),
						'type' => 'text',				
						'value' => 'welcome to Orange'
					),			

					array(
						'name' => 'sec_content',
						'label' => esc_html__( 'Content', 'orange' ),
						'type' => 'textarea',				
						'value' => 'A Theme for Creatives & Agencies.'
					),			
	

					array(
						'name' => 'sec_btn_text',
						'label' => esc_html__( 'Button Text', 'orange' ),
						'type' => 'text',				
						'value' => 'Contact Us'
					),		

					array(
						'name' => 'sec_btn_link',
						'label' => esc_html__( 'Button Link', 'orange' ),
						'type' => 'text',				
						'value' => '#contact'
					),		
		
	            ),  // End of elemnt kc_icon 

	        ) ) 
			
	    ); // End add map		

	 	    
		kc_add_map(
	        array(

	            'about_us_area' => array(
				'name' => esc_html__('About Us', 'orange'),
				'icon' => 'kc-icon-progress',
				'category' => 'Orange Shortcodes',
				'css_box' => true,
				'params' => array(	

						array(
							'name' => 'sec_title',
							'label' => esc_html__( 'Title', 'orange' ),
							'type' => 'text',
							'value' => 'Perfect for Creatives & Agencies',
							
						),					
					
						array(
							'type' => 'textarea',
							'label' => esc_html__( 'SubTitle', 'orange' ),
							'name' => 'sec_subtitle',
							'description' => esc_html__( 'Enter Content Here.', 'orange' ),
							'admin_label' => true,
							'value' => 'This template is perfect for Creatives & Agencies',
						),			

						array(
							'type' => 'text',
							'label' => esc_html__( 'Number of Post', 'orange' ),
							'name' => 'numb_post',	
							'admin_label' => true,
							'value' => '4',
						),			

	
					  )
					)

	        )); // End add map	
	 	    
		kc_add_map(
	        array(

	            'about_me_area' => array(
				'name' => esc_html__('About Me', 'orange'),
				'icon' => 'kc-icon-progress',
				'category' => 'Orange Shortcodes',
				'css_box' => true,
				'params' => array(	

					array(
						'name' => 'sec_img',
						'label' => esc_html__( 'Section Image', 'orange' ),
						'type' => 'attach_image',					
					),	
					
					array(
						'name' => 'sec_title',
						'label' => esc_html__( 'Title', 'orange' ),
						'type' => 'text',
						'value' => 'Hi, I\'m James Simmons',						
					),					
				
					array(
						'type' => 'textarea',
						'label' => esc_html__( 'Section Content', 'orange' ),
						'name' => 'sec_content',
						'description' => esc_html__( 'Enter Content Here.', 'orange' ),
						'admin_label' => true,
						'value' => '
							<p>The person who designed and built WrapBootstrap. He\'s a programmer and web developer who enjoys a diverse array of hobbies, including building web apps, working with big data, and reverse engineering. He will be the one that answers all your questions and will assist you if you should run into any trouble.</p>
							<p>Bootstrap has reached wide-spread adoption among developers and many have expressed their desire for design customization beyond the default styles. This marketplace was created to solve that need by allowing designers to upload and sell their own templates and themes based on Bootstrap.</p>						
						',
					),			

				  )
				)

	    )); // End add map	


		kc_add_map(
	        array(

	            'team_area' => array(
	                'name' => esc_html__('Team Area', 'orange'),
	                'icon' => 'kc-icon-progress',
	                'category' => 'Orange Shortcodes',
	                'params' => array(
	                
						array(
							'name' => 'sec_title',
							'label' => esc_html__( 'Section Title', 'orange' ),
							'type' => 'text',							
							'value' => 'Meet our experts',
							'admin_label' => true,
						),	
			
	                    array(
							'name' => 'sec_subtitle',
							'label' => esc_html__( 'Section SubTitle', 'orange' ),
							'type' => 'textarea',							
							'value' => 'Meet our experts for any kind of discussion',
							'admin_label' => true,
						),		 
						
						array(
							'name' => 'num_of_post',
							'label' => esc_html__( 'Number of Post', 'orange' ),
							'type' => 'text',							
							'value' => '-1',
							'admin_label' => true,
						),	 
	       	                             

	                )
	            ),  // End of elemnt kc_icon 

	        ) 
			
	    ); // End add map		
		
		
		kc_add_map(
	        array(

	            'promotion_area' => array(
				'name' => esc_html__('Promo Area', 'orange'),
				'icon' => 'kc-icon-progress',
				'category' => 'Orange Shortcodes',
				'css_box' => true,
				'params' => array(	
					
						array(
							'name' => 'sec_bg_image',
							'label' => esc_html__( 'Background Image', 'orange' ),
							'type' => 'attach_image',
							
						),

						array(
							'name' => 'sec_content',
							'label' => esc_html__( 'Section Content', 'orange' ),
							'type' => 'textarea',							
							'value' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer porttitor massa sed velit egestas.',
							'admin_label' => true,
						),	 

						array(
							'type' => 'text',
							'label' => esc_html__( 'Button Text', 'orange' ),
							'name' => 'sec_btn_text',
							'description' => esc_html__( 'Enter Button Text Here.', 'orange' ),
							'admin_label' => true,
							'value' => 'how we work',
						),			

	
						array(
							'type' => 'text',
							'label' => esc_html__( 'Button Link', 'orange' ),
							'name' => 'sec_btn_link',
							'description' => esc_html__( 'Enter Button link Here.', 'orange' ),
							'admin_label' => true,
							'value' => '#process',
						),						
					)
	
	            ),  // End of elemnt kc_icon 

	        ) 
			
	    ); // End add map	
		
		
		kc_add_map(
	        array(

	            'process_area' => array(
	                'name' => esc_html__('Process Area', 'orange'),
	                'icon' => 'kc-icon-progress',
	                'category' => 'Orange Shortcodes',
	                'params' => array(
	      
	                    array(
							'name' => 'sec_title',
							'label' => esc_html__( 'Section Title', 'orange' ),
							'type' => 'text',							
							'value' => 'Our process',
							'admin_label' => true,
						),	
	
	                    array(
							'name' => 'sec_content',
							'label' => esc_html__( 'Section Content', 'orange' ),
							'type' => 'textarea',							
							'value' => 'Meet our experts for any kind of discussion',
							'admin_label' => true,
						),		 
						
						array(
							'name' => 'num_of_post',
							'label' => esc_html__( 'Number of Post', 'orange' ),
							'type' => 'text',							
							'value' => '3',
							'admin_label' => true,
						),		

	                )
	            ),  // End of elemnt kc_icon 

	        ) 
			
	    ); // End add map	

		
		kc_add_map(
	        array(

	            'project_area' => array(
	                'name' => esc_html__('Project Area', 'orange'),
	                'icon' => 'kc-icon-progress',
	                'category' => 'Orange Shortcodes',
	                'params' => array(
	      
	                    array(
							'name' => 'sec_title',
							'label' => esc_html__( 'Section Title', 'orange' ),
							'type' => 'text',							
							'value' => 'Recent projects',
							'admin_label' => true,
						),	
	
	                    array(
							'name' => 'sec_content',
							'label' => esc_html__( 'Section Content', 'orange' ),
							'type' => 'textarea',							
							'value' => 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed.',
							'admin_label' => true,
						),		 
						
						array(
							'name' => 'num_of_post',
							'label' => esc_html__( 'Number of Post', 'orange' ),
							'type' => 'text',							
							'value' => '-1',
							'admin_label' => true,
						),		
						
						array(
							'name' => 'pro_link_text',
							'label' => esc_html__( 'Link Text', 'orange' ),
							'type' => 'text',							
							'value' => 'View Project',
							'admin_label' => true,
						),		

	                )
	            ),  // End of elemnt kc_icon 

	        ) 
			
	    ); // End add map	

		
		kc_add_map(
	        array(

	            'work_area' => array(
	                'name' => esc_html__('Work Area', 'orange'),
	                'icon' => 'kc-icon-progress',
	                'category' => 'Orange Shortcodes',
	                'params' => array(
	      
	                    array(
							'name' => 'sec_title',
							'label' => esc_html__( 'Section Title', 'orange' ),
							'type' => 'text',							
							'value' => 'Our portfolio',
							'admin_label' => true,
						),	
	
	                    array(
							'name' => 'sec_subtitle',
							'label' => esc_html__( 'Section Content', 'orange' ),
							'type' => 'textarea',							
							'value' => 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed.',
							'admin_label' => true,
						),		 
						
						array(
							'name' => 'num_of_post',
							'label' => esc_html__( 'Number of Post', 'orange' ),
							'type' => 'text',							
							'value' => '-1',
							'admin_label' => true,
						),		

	                )
	            ),  // End of elemnt kc_icon 

	        ) 
			
	    ); // End add map

		
		kc_add_map(
	        array(

	            'testimonials_area' => array(
	                'name' => esc_html__('Testimonials Area', 'orange'),
	                'icon' => 'kc-icon-progress',
	                'category' => 'Orange Shortcodes',
	                'params' => array(	                

	                    array(
							'name' => 'sec_title',
							'label' => esc_html__( 'Section Title', 'orange' ),
							'type' => 'text',							
							'value' => 'Client testimonials',
							'admin_label' => true,
						),	
							       
	                    array(
							'name' => 'sec_subtitle',
							'label' => esc_html__( 'Section SubTitle', 'orange' ),
							'type' => 'textarea',							
							'value' => 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed.',
							'admin_label' => true,
						),
						
						array(
							'name' => 'num_of_post',
							'label' => esc_html__( 'Number of Post', 'orange' ),
							'type' => 'text',							
							'value' => '-1',
							'admin_label' => true,
						),		
   	                             

	                )
	            ),  // End of elemnt kc_icon 

	        ) 
			
	    ); // End add map			
		
		kc_add_map(
	        array(

	            'pricing_area' => array(
	                'name' => esc_html__('Pricing Area', 'orange'),
	                'icon' => 'kc-icon-progress',
	                'category' => 'Orange Shortcodes',
	                'params' => array(	                
	        
						array(
							'name' => 'sec_bg_image',
							'label' => esc_html__( 'Background Image', 'orange' ),
							'type' => 'attach_image',							
							'admin_label' => true,
						),	  
						
						array(
							'name' => 'sec_title',
							'label' => esc_html__( 'Section Title', 'orange' ),
							'type' => 'text',							
							'value' => 'Pricing plan',
							'admin_label' => true,
						),	

						array(
							'name' => 'sec_subtitle',
							'label' => esc_html__( 'Section SubTitle', 'orange' ),
							'type' => 'textarea',							
							'value' => 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed.',
							'admin_label' => true,
						),	
						
						array(
							'name' => 'num_of_post',
							'label' => esc_html__( 'Number of Post', 'orange' ),
							'type' => 'text',							
							'value' => '3',
							'admin_label' => true,
						),		
   	                             

	                )
	            ),  // End of elemnt kc_icon 

	        ) 
			
	    ); // End add map	
		
		
		kc_add_map(
	        array(

	            'newsletter_area' => array(
	                'name' => esc_html__('Newsletter Area', 'orange'),
	                'icon' => 'kc-icon-progress',
	                'category' => 'Orange Shortcodes',
	                'params' => array(	                
	        
						array(
							'name' => 'sec_title',
							'label' => esc_html__( 'Section Title', 'orange' ),
							'type' => 'text',							
							'value' => 'Subscribe today for new updates',
							'admin_label' => true,
						),	
						
						array(
							'name' => 'newsletter_sort_id',
							'label' => esc_html__( 'Newsletter Sortcode ID', 'orange' ),
							'type' => 'text',											
							'admin_label' => true,
						),	
      

	                )
	            ),  // End of elemnt kc_icon 

	        ) 
			
	    ); // End add map	

		
		kc_add_map(
	        array(

	            'contact_us_area' => array(
	                'name' => esc_html__('Contact Us Area', 'orange'),
	                'icon' => 'kc-icon-progress',
	                'category' => 'Orange Shortcodes',
	                'params' => array(	                
	        
						array(
							'name' => 'sec_title',
							'label' => esc_html__( 'Section Title', 'orange' ),
							'type' => 'text',							
							'value' => 'Get in touch',
							'admin_label' => true,
						),	
						
						array(
							'name' => 'sec_subtitle',
							'label' => esc_html__( 'Section Title', 'orange' ),
							'type' => 'textarea',							
							'value' => 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed.',
							'admin_label' => true,
						),	
						
						array(
							'name' => 'cont_form_short',
							'label' => esc_html__( 'Contact Form Shortcode', 'orange' ),
							'type' => 'textarea',														
							'admin_label' => true,
						),	
	
	                )
	            ),  // End of elemnt kc_icon 

	        ) 
			
	    ); // End add map

		
		kc_add_map(
	        array(

	            'buy_now_area' => array(
	                'name' => esc_html__('Buy Now Area', 'orange'),
	                'icon' => 'kc-icon-progress',
	                'category' => 'Orange Shortcodes',
	                'params' => array(	                
	        
						array(
							'name' => 'sec_content',
							'label' => esc_html__( 'Section Content', 'orange' ),
							'type' => 'textarea',							
							'value' => 'Ready to get start with Orange?',
							'admin_label' => true,
						),	
						
						array(
							'name' => 'sec_btn_text',
							'label' => esc_html__( 'Button Text', 'orange' ),
							'type' => 'text',							
							'value' => 'Buy now',
							'admin_label' => true,
						),	
												
						array(
							'name' => 'sec_btn_link',
							'label' => esc_html__( 'Button Link', 'orange' ),
							'type' => 'text',							
							'value' => '#',
							'admin_label' => true,
						),	
						

	                )
	            ),  // End of elemnt kc_icon 

	        ) 
			
	    ); // End add map			
		
	

	

	} // End if

}  
 
