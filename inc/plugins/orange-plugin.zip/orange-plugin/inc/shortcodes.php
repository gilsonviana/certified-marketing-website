<?php

//Banner Area
function orange_banner_area( $atts , $content = null ){
 // Attributes
    extract( shortcode_atts(
        array(         	
			'ripple_opt' => '',		
			'sec_bg_img' => '',		
			'sec_title' => 'welcome to Orange',		
			'sec_content' => 'A Theme for Creatives & Agencies.',		
			'sec_btn_text' =>'Contact Us',		
			'sec_btn_link' =>'#contact',		
			
		), $atts )
    );
ob_start();
$sec_bg_img = wp_get_attachment_image_src($sec_bg_img , '' );

?>


<!-- START HOME -->
<section data-stellar-background-ratio="0.3" id="home" class="home_parallax <?php if($ripple_opt == '1'){ echo esc_attr('ripple');}?>" style="background-image: url(<?php echo esc_url($sec_bg_img[0]);?>);  background-size:cover; background-position: center center;">			
	<div class="container">
		<div class="row">
		  <div class="col-md-12 text-center">
			<div class="hero-text">
				<h1><?php echo orange_wp_kses($sec_title);?></h1>
				<p><?php echo orange_wp_kses($sec_content);?></p>
				<?php if($sec_btn_link & $sec_btn_text ){ ?>
				<a href="<?php echo esc_url($sec_btn_link);?>" class="page-scroll btn btn-default btn-home-bg"><?php echo esc_html($sec_btn_text);?></a>						
				<?php } ?>
			</div>
		  </div><!--- END COL -->		  
		</div><!--- END ROW -->
	</div><!--- END CONTAINER -->
</section>
<!-- END  HOME DESIGN -->

<?php 

  return ob_get_clean();
}
add_shortcode ('banner_area', 'orange_banner_area' );


//About Us Area
function orange_about_us_area( $atts , $content = null ){
 // Attributes
    extract( shortcode_atts(
        array(         
			'sec_title' => 'Perfect for Creatives & Agencies',		
			'sec_subtitle' => 'This template is perfect for Creatives & Agencies',			
			'numb_post' => '4',		
		
			
		), $atts )
    );
ob_start();

?>


<!-- START ABOUT -->
<section id="about" class="about_us section-padding">
   <div class="container">
		<div class="row">
			<div class="col-md-12 text-center">
				<div class="section-title">
					<h1><?php echo esc_html($sec_title);?></h1>
					<span></span>
					<p><?php echo orange_wp_kses($sec_subtitle);?></p>
				</div>
			</div>
		</div>
		
		<div class="row text-center">
			<?php
				// WP_Query arguments
				$args = array(
					'post_type'              => array( 'about' ),
					'posts_per_page'         => $numb_post,
				);

				// The Query
				$orange_about_query = new WP_Query( $args );

				// The Loop
				if ( $orange_about_query->have_posts() ) {
					while ( $orange_about_query->have_posts() ) {
						$orange_about_query->the_post();
						$orange_about_icon = get_post_meta(get_the_ID(), '_orange_about_icon', true);
						
						?>
					
						<div class="col-lg-3 col-sm-6 col-xs-12" data-aos="fade-up">
							<div class="serviceBox">
								<div class="service-icon"><i class="<?php echo esc_attr($orange_about_icon);?>"></i></div>
								<h3 class="title"><?php the_title();?></h3>
								<div class="description">
									<?php the_content();?>
								</div>
							</div>
						</div><!-- END COL -->						
						<?php
					}
				} else {
					// no posts found
				}

				// Restore original Post Data
				wp_reset_postdata();
			?>		
			
		
		</div><!-- END ROW -->
	</div><!-- END CONTAINER -->
</section>
<!-- END ABOUT -->	
<?php 

  return ob_get_clean();
}
add_shortcode ('about_us_area', 'orange_about_us_area' );

//About Me Area
function orange_about_me_area( $atts , $content = null ){
 // Attributes
    extract( shortcode_atts(
        array(         
			'sec_img' => '',		
			'sec_title' => 'Hi, I\'m James Simmons',			
			'sec_content' => '<p>The person who designed and built WrapBootstrap. He\'s a programmer and web developer who enjoys a diverse array of hobbies, including building web apps, working with big data, and reverse engineering. He will be the one that answers all your questions and will assist you if you should run into any trouble.</p>
							<p>Bootstrap has reached wide-spread adoption among developers and many have expressed their desire for design customization beyond the default styles. This marketplace was created to solve that need by allowing designers to upload and sell their own templates and themes based on Bootstrap.</p>',		
		
			
		), $atts )
    );
ob_start();
$sec_img = wp_get_attachment_image_src($sec_img , '' );
?>

<section id="about" class="about_me section-padding">
   <div class="container">
		<div class="row">					
			<div class="col-lg-6 col-sm-6 col-xs-12 aos-init aos-animate" data-aos="fade-up">
				<div class="single_about_img">
					<img src="<?php echo esc_url($sec_img[0]);?>" alt="<?php echo esc_attr($sec_title);?>">
				</div>
			</div><!-- END COL -->					
			<div class="col-lg-6 col-sm-6 col-xs-12 aos-init aos-animate" data-aos="fade-up">
				<div class="single_about">
					<h1><?php echo esc_html($sec_title);?></h1>
					<span></span>
					<?php echo orange_wp_kses($sec_content);?>
				</div>
			</div><!-- END COL -->				
		</div><!-- END ROW -->
	</div><!-- END CONTAINER -->
</section>

<?php 

  return ob_get_clean();
}
add_shortcode ('about_me_area', 'orange_about_me_area' );

//Team Area
function orange_team_area( $atts , $content = null ){
 // Attributes
    extract( shortcode_atts(
        array(         
			'sec_title' => 'Meet our experts',			
			'sec_subtitle' => 'Meet our experts for any kind of discussion',		
			'num_of_post' => '-1',	
		
		), $atts )
    );
ob_start();


?>

<!-- START TEAM -->
<section id="team" class="our_team section-padding">
   <div class="container">
		<div class="row">
			<div class="col-md-12 text-center">
				<div class="section-title">
					<h1><?php echo esc_html($sec_title);?></h1>
					<span></span>
					<p><?php echo orange_wp_kses($sec_subtitle);?></p>
				</div>
			</div>
		</div>
		<div class="row">					
			<div class="col-xs-12 col-lg-12" data-aos="fade-up">
				<div id="team-slider" class="owl-carousel">
					<?php
					// WP_Query arguments
					$args = array(
						'post_type'              => array( 'team' ),
						'posts_per_page'         => $num_of_post,
					);

					// The Query
					$orange_team_query = new WP_Query( $args );

					// The Loop
					if ( $orange_team_query->have_posts() ) {
						while ( $orange_team_query->have_posts() ) {
							$orange_team_query->the_post();
							$orange_team_designation = get_post_meta(get_the_ID(), '_orange_team_designation', true);
							$orange_team_group_field_opt = get_post_meta(get_the_ID(), '_orange_team_group_field_opt', true);
							
							?>
								

								<div class="our-team">
									<?php the_post_thumbnail('orange_image_370_420', array('class' => 'img-responsive')); ?>
									<div class="team-content">
										<h3 class="title"><?php the_title();?></h3>
										<span class="post"><?php echo esc_html($orange_team_designation);?></span>
									</div>
									<ul class="social">
									<?php
										foreach ( (array) $orange_team_group_field_opt as $key => $team_entry ) {

											$icon = $link = '';

											if ( isset( $team_entry['_orange_team_social_icon'] ) )
												$icon = $team_entry['_orange_team_social_icon'] ;

											if ( isset( $team_entry['_orange_team_social_link'] ) )
												$link = $team_entry['_orange_team_social_link'] ;	

											?>
											
										 <li><a href="<?php echo esc_url($link);?>"><i class="<?php echo esc_attr($icon);?>"></i></a></li>
										 
										<?php } ?>									
									</ul>
									<div class="icon fa fa-plus"></div>
								</div><!-- END OUR-TEAM -->							
							<?php
							
						}
					} else {
						// no posts found
					}

					// Restore original Post Data
					wp_reset_postdata();
				?>							
					
				</div>
			</div><!-- END COL -->				
		</div><!-- END ROW -->
	</div><!-- END CONTAINER -->
</section>
<!-- END TEAM -->	
<?php 

  return ob_get_clean();
}
add_shortcode ('team_area', 'orange_team_area' );


//Promotion Area
function orange_promotion_area( $atts , $content = null ){
 // Attributes
    extract( shortcode_atts(
        array(         
			'sec_bg_image' => '',			
			'sec_content' => 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer porttitor massa sed velit egestas.',		
			'sec_btn_text' => 'how we work',	
			'sec_btn_link' => '#process',	
		
		), $atts )
    );
ob_start();
$sec_bg_image = wp_get_attachment_image_src($sec_bg_image , '' );

?>

<!-- START PROMOTION  -->
<section data-stellar-background-ratio="0.3" class="promotion_offer" style="background-image: url(<?php echo esc_url($sec_bg_image[0]);?>); background-size:cover; background-position: center center;">
	<div class="container">
		<div class="row">
			<div class="text-center col-xs-12" data-aos="fade-up">
				<div class="promotion_content">
					<p><?php echo orange_wp_kses($sec_content);?></p>
					<a href="<?php echo esc_url($sec_btn_link);?>" class="page-scroll btn btn-lg btn-promotion-bg"><?php echo esc_html($sec_btn_text);?></a>	
				</div>
			</div><!-- END COL  -->
		</div><!--END  ROW  -->
	</div><!-- END CONTAINER  -->
</section>
<!-- END PROMOTION -->
<?php 

  return ob_get_clean();
}
add_shortcode ('promotion_area', 'orange_promotion_area' );


//Process Area
function orange_process_area( $atts , $content = null ){
 // Attributes
    extract( shortcode_atts(
        array(         
			'sec_title' => 'Our process',			
			'sec_content' => 'Meet our experts for any kind of discussion',		
			'num_of_post' => '3',	
		
		), $atts )
    );
ob_start();

?>

<!-- START PROCESS -->
<section id="process" class="our_service section-padding">
	<div class="container">			
		<div class="row">
			<div class="col-md-12 text-center">
				<div class="section-title">
					<h1><?php echo orange_wp_kses($sec_title);?></h1>
					<span></span>
					<p><?php echo orange_wp_kses($sec_content);?></p>
				</div>
			</div>
		</div>
		<div class="row" data-aos="fade-up">
			<?php
					// WP_Query arguments
					$args = array(
						'post_type'              => array( 'process' ),
						'posts_per_page'         => $num_of_post,
					);

					// The Query
					$orange_process_query = new WP_Query( $args );

					// The Loop
					if ( $orange_process_query->have_posts() ) {
						while ( $orange_process_query->have_posts() ) {
							$orange_process_query->the_post();
							$orange_process_icon = get_post_meta(get_the_ID(), '_orange_process_icon', true);
							$orange_process_group_field_opt = get_post_meta(get_the_ID(), '_orange_process_group_field_opt', true);
							
							?>
								
							<div class="col-xs-12 col-sm-4">
								<div class="single_service">							
									<i class="<?php echo esc_attr($orange_process_icon)?>"></i> 
									<h3><?php the_title();?></h3>
									<p><?php the_content();?></p>
									<ul>
										  
										<?php
										foreach ( (array) $orange_process_group_field_opt as $key => $process_entry ) {

											$icon = $content = '';

											if ( isset( $process_entry['_orange_process_list_icon'] ) )
												$icon = $process_entry['_orange_process_list_icon'] ;

											if ( isset( $process_entry['_orange_process_text'] ) )
												$content = $process_entry['_orange_process_text'] ;	

											?>
						
										 <li><i class="<?php echo esc_attr($icon);?>"></i> <?php echo esc_html($content);?></li>
										<?php } ?>											
									</ul>
								</div>
							</div><!-- END COL  -->
											
							<?php
							
						}
					} else {
						// no posts found
					}

					// Restore original Post Data
					wp_reset_postdata();
				?>					
	
		</div><!--- END ROW -->
	</div><!--- END CONTAINER -->
</section>
<!-- END PROCESS -->

<?php 

  return ob_get_clean();
}
add_shortcode ('process_area', 'orange_process_area' );


//Project Area
function orange_project_area( $atts , $content = null ){
 // Attributes
    extract( shortcode_atts(
        array(         
			'sec_title' => 'Recent projects',			
			'sec_content' => 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed.',		
			'num_of_post' => '-1',	
			'pro_link_text' => 'View Project',	
		
		), $atts )
    );
ob_start();

?>

<!-- START PROJECTS  -->
<section id="work" class="our_work section-padding">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="section-title text-center">
					<h1><?php echo orange_wp_kses($sec_title);?></h1>
					<span></span>
					<p><?php echo orange_wp_kses($sec_content);?></p>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-12 col-xs-12" data-aos="fade-up">
				<div id="gallery-slider" class="owl-carousel">
					<?php
					// WP_Query arguments
					$args = array(
						'post_type'              => array( 'project' ),
						'posts_per_page'         => $num_of_post,
					);

					// The Query
					$orange_project_query = new WP_Query( $args );

					// The Loop
					if ( $orange_project_query->have_posts() ) {
						while ( $orange_project_query->have_posts() ) {
							$orange_project_query->the_post();
							$orange_project_sub_title = get_post_meta(get_the_ID(), '_orange_project_sub_title', true);
							
							?>
							
							<div class="single_gallery">
								<?php the_post_thumbnail('orange_image_1920_1200', array('class' => 'img-gallery')); ?>							
								<div class="gallery_overlay"></div>
								<div class="gallery_info">
									<h1><?php echo the_title();?></h1>
									<p><?php echo esc_html($orange_project_sub_title);?></p>
									<a href="#" data-toggle="modal" data-target="#projectModal<?php echo esc_attr(get_the_ID());?>"><?php echo esc_html($pro_link_text);?></a>
								</div>
							</div><!-- END SINGLE GALLERY -->	
				
											
							<?php
							
						}
					} else {
						// no posts found
					}

					// Restore original Post Data
					wp_reset_postdata();
				?>					
					
		
				</div>
			</div><!-- END COL  -->
			
			
			<div class="col-md-12">
			
					<?php
					// WP_Query arguments
					$args = array(
						'post_type'              => array( 'project' ),
						'posts_per_page'         => $num_of_post,
					);

					// The Query
					$orange_project_two_query = new WP_Query( $args );

					// The Loop
					if ( $orange_project_two_query->have_posts() ) {
						while ( $orange_project_two_query->have_posts() ) {
							$orange_project_two_query->the_post();
							$orange_project_details_title = get_post_meta(get_the_ID(), '_orange_project_details_title', true);
							$orange_project_client_label = get_post_meta(get_the_ID(), '_orange_project_client_label', true);
							$orange_project_client = get_post_meta(get_the_ID(), '_orange_project_client', true);
							$orange_project_date_label = get_post_meta(get_the_ID(), '_orange_project_date_label', true);
							$orange_project_date = get_post_meta(get_the_ID(), '_orange_project_date', true);
							$orange_project_url_label = get_post_meta(get_the_ID(), '_orange_project_url_label', true);
							$orange_project_url = get_post_meta(get_the_ID(), '_orange_project_url', true);
							
							?>
							
								<!-- Overlay Modal  -->
								<div  tabindex="0" class="modal fade" id="projectModal<?php echo esc_html(get_the_ID());?>">
									<div class="modal-dialog">
										<div class="modal-content">
											<div class="modal-header">
												<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
												<h4 class="modal-title"><?php echo esc_html($orange_project_details_title);?></h4>
											</div>
											<div class="modal-body">
												<?php the_post_thumbnail('orange_image_1920_1200', array('class' => 'img-responsive')); ?>		
												<p><?php the_content();?></p>
												
												 <ul class="list-unstyled project-list" >
													<li><label><?php echo esc_html($orange_project_client_label);?> </label> <?php echo esc_html($orange_project_client_label);?></li>						
													<li><label><?php echo esc_html($orange_project_date_label);?> </label> <?php echo esc_html($orange_project_date);?></li>
													<li><label><?php echo esc_html($orange_project_url_label);?> </label> <a href="<?php echo esc_url($orange_project_url);?>"><?php echo esc_html($orange_project_url);?></a></li>
												</ul>
										  </div>
										</div><!-- /.modal-content -->
									</div><!-- /.modal-dialog -->
								</div><!-- /.modal -->			
							<?php
							
						}
					} else {
						// no posts found
					}

					// Restore original Post Data
					wp_reset_postdata();
				?>	
				
	
			</div>				
		</div><!--END  ROW  -->
	</div><!-- END CONTAINER  -->
</section>
<!-- END PROJECTS -->
		
<?php 

  return ob_get_clean();
}
add_shortcode ('project_area', 'orange_project_area' );


//Work Area
function orange_work_area( $atts , $content = null ){
 // Attributes
    extract( shortcode_atts(
        array(         

			'sec_title' => 'Our portfolio',			
			'sec_subtitle' => 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed.',			
			'num_of_post' => '-1',			
	
		), $atts )
    );
ob_start();


?>	

<!-- START PROJECTS -->
<section class="recent-projects">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="section-title text-center">
					<h1><?php echo orange_wp_kses($sec_title);?></h1>
					<span></span>
					<p><?php echo orange_wp_kses($sec_subtitle);?></p>
				</div>
			</div>
		</div>
		<div class="row">
			<?php $terms = get_terms('work_cat');
					if ( ! empty( $terms ) && ! is_wp_error( $terms ) ){
				?>
			<ul class="portfolio-filters text-center">
				<li class="filter active" data-filter="all"><?php esc_html_e('All' , 'orange');?></li>
				<?php foreach ( $terms as $term ) : ?>
				<li class="filter" data-filter="<?php echo esc_attr($term->slug); ?>"><?php echo esc_html($term->name); ?></li>			
				<?php endforeach;?>
			</ul>
		<?php } ?>

			<!-- END PORTFOLIO FILTER-->
			<div class="grid">

			<?php
				// WP_Query arguments
				$args = array(
					'post_type'              => array( 'work' ),
					'posts_per_page'         => $num_of_post,
				);

				// The Query
				$orange_works_query = new WP_Query( $args );

				// The Loop
				if ( $orange_works_query->have_posts() ) {
					while ( $orange_works_query->have_posts() ) {
						$orange_works_query->the_post();
						$orange_work_subtitle = get_post_meta(get_the_ID(), '_orange_portfolio_sub_title', true);
						$orange_work_image = wp_get_attachment_image_src(get_post_thumbnail_id(get_the_ID()),'orange_image_1200_800');		
						$portfolio_terms = get_the_terms(get_the_id(), 'work_cat');
						if ( ! empty( $portfolio_terms ) && ! is_wp_error( $portfolio_terms ) ):
							
							$portfolios_cat_slug = array();
							
							foreach($portfolio_terms as $portfolio_term){
								$portfolios_cat_slug[] = $portfolio_term->slug ;
							}
							
							$portfolios_cat_array = join(" ", $portfolios_cat_slug);
							$portfolios_class_array = join(" ", $portfolios_cat_slug);
						endif;						
						?>
									
							<div class="col-xs-12 col-sm-4 mix <?php echo esc_attr($portfolios_class_array);?>">						
								<div class="box">
									<?php the_post_thumbnail('orange_image_1200_800', array('class' => 'img-responsive')); ?>
									<div class="box-content">
										<h3 class="title"><a href="<?php echo esc_url($orange_work_image[0]);?>" class="image-popup"><?php the_title();?></a></h3>
										<span class="post"><?php echo esc_html($orange_work_subtitle);?></span>
									</div>
								</div>
							</div><!--- END COL -->						
						<?php
					}
				} else {
					// no posts found
				}

				// Restore original Post Data
				wp_reset_postdata();	
			?>			
		
				
			</div><!--- END GRID -->
		</div><!--- END ROW -->
	</div><!--- END CONTAINER -->
</section>
<!-- END PROJECTS -->
<?php 

  return ob_get_clean();
}
add_shortcode ('work_area', 'orange_work_area' );


//Testimonials Area
function orange_testimonials_area( $atts , $content = null ){
 // Attributes
    extract( shortcode_atts(
        array(         
			'sec_title' => 'Client testimonials',			
			'sec_subtitle' => 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed.',		
			'num_of_post' => '-1',				
		), $atts )
    );
ob_start();


?>

	<!-- START TESTIMONIALS  -->
	<section id="testimonial" class="our_testimonial section-padding">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="section-title text-center">
						<h1><?php echo orange_wp_kses($sec_title);?></h1>
						<span></span>
						<p><?php echo orange_wp_kses($sec_subtitle);?></p>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-xs-12" data-aos="fade-up">
					<div id="testimonial-slider" class="owl-carousel">

						<?php
							// WP_Query arguments
							$args = array(
								'post_type'              => array( 'testimonials' ),
								'posts_per_page'         => $num_of_post,
							);

							// The Query
							$orange_testi_query = new WP_Query( $args );

							// The Loop
							if ( $orange_testi_query->have_posts() ) {
								while ( $orange_testi_query->have_posts() ) {
									$orange_testi_query->the_post();
									$orange_testimonials_designation = get_post_meta(get_the_ID(), '_orange_testimonials_designation', true);
									
									?>
									
									<div class="testimonial">
										<div class="pic">
											<?php the_post_thumbnail('orange_image_90_90', array('class' => 'img-responsive')); ?>
										</div>
										<div class="testimonial-profile">
											<h3 class="title"><?php the_title();?></h3>
											<span class="post"><?php echo esc_html($orange_testimonials_designation);?></span>
										</div>
										<p class="description">
											<?php the_content();?>
										</p>
									</div>							
									<?php
			
								}
							} else {
								// no posts found
							}

							// Restore original Post Data
							wp_reset_postdata();
						?>								

					</div>
				</div><!-- END COL  -->
			</div><!--END  ROW  -->
		</div><!-- END CONTAINER  -->
	</section>
	<!-- END TESTIMONIALS -->
		
<?php 

  return ob_get_clean();
}
add_shortcode ('testimonials_area', 'orange_testimonials_area' );

//Pricing Area
function orange_pricing_area( $atts , $content = null ){
 // Attributes
    extract( shortcode_atts(
        array(         		
			'sec_bg_image' => '',			
			'sec_title' => 'Pricing plan',			
			'sec_subtitle' => 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed.',		
			'num_of_post' => '3',	
			
		), $atts )
    );
ob_start();

$sec_bg_image = wp_get_attachment_image_src($sec_bg_image , '' );

?>

<!-- START PRICING  -->
<section id="pricing" class="our_pricing section-padding" style="background-image: url(<?php echo esc_url($sec_bg_image[0]);?>); background-size:cover; background-position: center center;background-attachment:fixed;">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="section-title text-center">
					<h1 class="section-title-white"><?php echo orange_wp_kses($sec_title);?></h1>
					<span></span>
					<p class="section-title-white"><?php echo orange_wp_kses($sec_subtitle);?></p>
				</div>
			</div>
		</div>
		<div class="row">
		
	<?php
				// WP_Query arguments
				$args = array(
					'post_type'              => array( 'pricing' ),
					'posts_per_page'         => $num_of_post,
				);

				// The Query
				$orange_pricing_query = new WP_Query( $args );

				// The Loop
				if ( $orange_pricing_query->have_posts() ) {
					while ( $orange_pricing_query->have_posts() ) {
						$orange_pricing_query->the_post();
						$orange_pricing_feat = get_post_meta(get_the_ID(), '_orange_pricing_feat', true);
						$orange_pricing_price = get_post_meta(get_the_ID(), '_orange_pricing_price', true);
						$orange_pricing_group_field_opt = get_post_meta(get_the_ID(), '_orange_pricing_group_field_opt', true);
						$orange_pricing_btn_text = get_post_meta(get_the_ID(), '_orange_pricing_btn_text', true);
						$orange_pricing_btn_link = get_post_meta(get_the_ID(), '_orange_pricing_btn_link', true);
						?>

						<div class="col-xs-12 col-sm-4" data-aos="fade-up">
							<div class="pricingTable <?php if($orange_pricing_feat == true){ echo esc_attr('feature');}?>">
								
								<div class="pricingTable-header">
									<div class="title_bg"></div>
									<h3 class="title"><?php the_title();?></h3>
									<span class="price-value"><?php echo esc_html($orange_pricing_price);?><small class="period"><?php esc_html_e('/month' , 'orange');?></small></span>
								</div>
								<ul class="pricing-content">
									<?php
										foreach ( (array) $orange_pricing_group_field_opt as $key => $pricing_entry ) {

											$features = '';

											if ( isset( $pricing_entry['_orange_pricing_feature'] ) )
												$features = $pricing_entry['_orange_pricing_feature'] ;	

											?>
										 <li><?php echo esc_html($features);?></li>
										 
									<?php } ?>								
			
								</ul>
								<a href="<?php echo esc_url($orange_pricing_btn_link);?>" class="btn btn-lg btn-contact-bg"><?php echo esc_html($orange_pricing_btn_text);?></a>
							</div>
						</div><!-- END COL  -->
									
						<?php
					}
				} else {
					// no posts found
				}

				// Restore original Post Data
				wp_reset_postdata();
			?>			
		
		</div><!--END  ROW  -->
	</div><!-- END CONTAINER  -->
</section>
<!-- END PRICING -->
<?php 

  return ob_get_clean();
}
add_shortcode ('pricing_area', 'orange_pricing_area' );

//Newsletter Area
function orange_newsletter_area( $atts , $content = null ){
 // Attributes
    extract( shortcode_atts(
        array(         		
			'sec_title' => 'Subscribe today for new updates',		
			'newsletter_sort_id' => '',		

		), $atts )
    );
ob_start();


?>

<!-- START NEWSLETTER -->
<section  class="newsletter_section">
	<div class="container">
		<div class="row">
			<div class="col-md-offset-2 text-center col-xs-12 col-md-8" data-aos="fade-up">
				<h1 class="newsletter-title"><?php echo orange_wp_kses($sec_title);?></h1>
				<?php if($newsletter_sort_id){ ?>
					<div class="newsletter_form">
						<span class="newsletter_form_border"></span>
						<?php echo do_shortcode('[mc4wp_form id="'.esc_attr(newsletter_sort_id).'"]');?>
					</div>
				<?php } ?>
			</div><!-- END COL -->
		</div><!-- END ROW -->
	</div><!-- END CONTAINER -->
</section>
<!-- END NEWSLETTER -->
		
<?php 

  return ob_get_clean();
}
add_shortcode ('newsletter_area', 'orange_newsletter_area' );


//Contact Us Area
function orange_contact_us_area( $atts , $content = null ){
 // Attributes
    extract( shortcode_atts(
        array(         		
			'sec_title' => 'Get in touch',		
			'sec_subtitle' => 'Lorem ipsum dolor sit amet consectetur adipisicing elitsed.',		
			'cont_form_short' => '',		

		), $atts )
    );
ob_start();


?>

<!-- START CONTACT -->
<section id="contact" class="contact_us section-padding">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="section-title text-center">
					<h1><?php echo orange_wp_kses($sec_title);?></h1>
					<span></span>
					<p><?php echo orange_wp_kses($sec_subtitle);?></p>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-md-offset-1 text-center col-xs-12 col-md-10" data-aos="fade-up">
				<div class="contact">
					<form id="contact-form" method="post" enctype="multipart/form-data">
						<?php echo do_shortcode($cont_form_short);?>
					</form>
				</div>
			</div><!-- END COL  -->
		</div><!-- END ROW -->
	</div><!-- END CONTAINER -->
</section>
<!-- END CONTACT -->
		
<?php 

  return ob_get_clean();
}
add_shortcode ('contact_us_area', 'orange_contact_us_area' );

//Buy Now Area
function orange_buy_now_area( $atts , $content = null ){
 // Attributes
    extract( shortcode_atts(
        array(         		

			'sec_content' => 'Ready to get start with Orange?',		
			'sec_btn_text' => 'Buy now',		
			'sec_btn_link' => '#',		

		), $atts )
    );
ob_start();


?>

<!-- PROMOTION -->
<section class="buy_now">
	<div class="container text-center">
		<h3 class="buy_now_title"><?php echo orange_wp_kses($sec_content);?></h3>
		<?php if($sec_btn_link){ ?>
			<a href="<?php echo esc_url($sec_btn_link);?>" class="btn btn-default btn-promotion-bg"><?php echo esc_html($sec_btn_text);?></a>
		<?php } ?>
	</div><!--- END CONTAINER -->
</section>
<!-- END PROMOTION -->
		
<?php 

  return ob_get_clean();
}
add_shortcode ('buy_now_area', 'orange_buy_now_area' );


//Shortcode Importer
function orange_shortcode_importer( $atts , $content = null ){
 // Attributes
    extract( shortcode_atts(
        array(                                   
            'enter_shortcode' => '',                                                                              

		), $atts )
    );

	echo do_shortcode($enter_shortcode);
}
add_shortcode ('shortcode_importer', 'orange_shortcode_importer' );
