<?php

if ( ! function_exists('orange_about') ) {

// Register About
function orange_about() {

	$labels = array(
		'name'                  => esc_html_x( 'About', 'Post Type General Name', 'orange' ),
		'singular_name'         => esc_html_x( 'About', 'Post Type Singular Name', 'orange' ),
		'menu_name'             => esc_html__( 'About', 'orange' ),
		'name_admin_bar'        => esc_html__( 'About', 'orange' ),
		'archives'              => esc_html__( 'Item Archives', 'orange' ),
		'attributes'            => esc_html__( 'Item Attributes', 'orange' ),
		'parent_item_colon'     => esc_html__( 'Parent Item:', 'orange' ),
		'all_items'             => esc_html__( 'All Items', 'orange' ),
		'add_new_item'          => esc_html__( 'Add New Item', 'orange' ),
		'add_new'               => esc_html__( 'Add New', 'orange' ),
		'new_item'              => esc_html__( 'New Item', 'orange' ),
		'edit_item'             => esc_html__( 'Edit Item', 'orange' ),
		'update_item'           => esc_html__( 'Update Item', 'orange' ),
		'view_item'             => esc_html__( 'View Item', 'orange' ),
		'view_items'            => esc_html__( 'View Items', 'orange' ),
		'search_items'          => esc_html__( 'Search Item', 'orange' ),
		'not_found'             => esc_html__( 'Not found', 'orange' ),
		'not_found_in_trash'    => esc_html__( 'Not found in Trash', 'orange' ),
		'featured_image'        => esc_html__( 'Featured Image', 'orange' ),
		'set_featured_image'    => esc_html__( 'Set featured image', 'orange' ),
		'remove_featured_image' => esc_html__( 'Remove featured image', 'orange' ),
		'use_featured_image'    => esc_html__( 'Use as featured image', 'orange' ),
		'insert_into_item'      => esc_html__( 'Insert into item', 'orange' ),
		'uploaded_to_this_item' => esc_html__( 'Uploaded to this item', 'orange' ),
		'items_list'            => esc_html__( 'Items list', 'orange' ),
		'items_list_navigation' => esc_html__( 'Items list navigation', 'orange' ),
		'filter_items_list'     => esc_html__( 'Filter items list', 'orange' ),
	);
	$args = array(
		'label'                 => esc_html__( 'About', 'orange' ),
		'description'           => esc_html__( 'Post Type Description', 'orange' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'   => 'dashicons-universal-access-alt',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
	);
	register_post_type( 'about', $args );

}
add_action( 'init', 'orange_about', 0 );

}


if ( ! function_exists('orange_team') ) {

// Register Team
function orange_team() {

	$labels = array(
		'name'                  => esc_html_x( 'Team', 'Post Type General Name', 'orange' ),
		'singular_name'         => esc_html_x( 'Team', 'Post Type Singular Name', 'orange' ),
		'menu_name'             => esc_html__( 'Team', 'orange' ),
		'name_admin_bar'        => esc_html__( 'Team', 'orange' ),
		'archives'              => esc_html__( 'Item Archives', 'orange' ),
		'attributes'            => esc_html__( 'Item Attributes', 'orange' ),
		'parent_item_colon'     => esc_html__( 'Parent Item:', 'orange' ),
		'all_items'             => esc_html__( 'All Items', 'orange' ),
		'add_new_item'          => esc_html__( 'Add New Item', 'orange' ),
		'add_new'               => esc_html__( 'Add New', 'orange' ),
		'new_item'              => esc_html__( 'New Item', 'orange' ),
		'edit_item'             => esc_html__( 'Edit Item', 'orange' ),
		'update_item'           => esc_html__( 'Update Item', 'orange' ),
		'view_item'             => esc_html__( 'View Item', 'orange' ),
		'view_items'            => esc_html__( 'View Items', 'orange' ),
		'search_items'          => esc_html__( 'Search Item', 'orange' ),
		'not_found'             => esc_html__( 'Not found', 'orange' ),
		'not_found_in_trash'    => esc_html__( 'Not found in Trash', 'orange' ),
		'featured_image'        => esc_html__( 'Team Image', 'orange' ),
		'set_featured_image'    => esc_html__( 'Set Team image', 'orange' ),
		'remove_featured_image' => esc_html__( 'Remove featured image', 'orange' ),
		'use_featured_image'    => esc_html__( 'Use as featured image', 'orange' ),
		'insert_into_item'      => esc_html__( 'Insert into item', 'orange' ),
		'uploaded_to_this_item' => esc_html__( 'Uploaded to this item', 'orange' ),
		'items_list'            => esc_html__( 'Items list', 'orange' ),
		'items_list_navigation' => esc_html__( 'Items list navigation', 'orange' ),
		'filter_items_list'     => esc_html__( 'Filter items list', 'orange' ),
	);
	$args = array(
		'label'                 => esc_html__( 'Team', 'orange' ),
		'description'           => esc_html__( 'Post Type Description', 'orange' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'thumbnail' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'   => 'dashicons-groups',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
	);
	register_post_type( 'team', $args );

}
add_action( 'init', 'orange_team', 0 );

}

if ( ! function_exists('orange_process') ) {

// Register Team
function orange_process() {

	$labels = array(
		'name'                  => esc_html_x( 'Process', 'Post Type General Name', 'orange' ),
		'singular_name'         => esc_html_x( 'Process', 'Post Type Singular Name', 'orange' ),
		'menu_name'             => esc_html__( 'Process', 'orange' ),
		'name_admin_bar'        => esc_html__( 'Process', 'orange' ),
		'archives'              => esc_html__( 'Item Archives', 'orange' ),
		'attributes'            => esc_html__( 'Item Attributes', 'orange' ),
		'parent_item_colon'     => esc_html__( 'Parent Item:', 'orange' ),
		'all_items'             => esc_html__( 'All Items', 'orange' ),
		'add_new_item'          => esc_html__( 'Add New Item', 'orange' ),
		'add_new'               => esc_html__( 'Add New', 'orange' ),
		'new_item'              => esc_html__( 'New Item', 'orange' ),
		'edit_item'             => esc_html__( 'Edit Item', 'orange' ),
		'update_item'           => esc_html__( 'Update Item', 'orange' ),
		'view_item'             => esc_html__( 'View Item', 'orange' ),
		'view_items'            => esc_html__( 'View Items', 'orange' ),
		'search_items'          => esc_html__( 'Search Item', 'orange' ),
		'not_found'             => esc_html__( 'Not found', 'orange' ),
		'not_found_in_trash'    => esc_html__( 'Not found in Trash', 'orange' ),
		'featured_image'        => esc_html__( 'Process Image', 'orange' ),
		'set_featured_image'    => esc_html__( 'Set Process image', 'orange' ),
		'remove_featured_image' => esc_html__( 'Remove featured image', 'orange' ),
		'use_featured_image'    => esc_html__( 'Use as featured image', 'orange' ),
		'insert_into_item'      => esc_html__( 'Insert into item', 'orange' ),
		'uploaded_to_this_item' => esc_html__( 'Uploaded to this item', 'orange' ),
		'items_list'            => esc_html__( 'Items list', 'orange' ),
		'items_list_navigation' => esc_html__( 'Items list navigation', 'orange' ),
		'filter_items_list'     => esc_html__( 'Filter items list', 'orange' ),
	);
	$args = array(
		'label'                 => esc_html__( 'Process', 'orange' ),
		'description'           => esc_html__( 'Post Type Description', 'orange' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'   => 'dashicons-lightbulb',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
	);
	register_post_type( 'Process', $args );

}
add_action( 'init', 'orange_process', 0 );

}

if ( ! function_exists('orange_project') ) {

// Register Project
function orange_project() {

	$labels = array(
		'name'                  => esc_html_x( 'Projects', 'Post Type General Name', 'orange' ),
		'singular_name'         => esc_html_x( 'Project', 'Post Type Singular Name', 'orange' ),
		'menu_name'             => esc_html__( 'Projects', 'orange' ),
		'name_admin_bar'        => esc_html__( 'Projects', 'orange' ),
		'archives'              => esc_html__( 'Item Archives', 'orange' ),
		'attributes'            => esc_html__( 'Item Attributes', 'orange' ),
		'parent_item_colon'     => esc_html__( 'Parent Item:', 'orange' ),
		'all_items'             => esc_html__( 'All Items', 'orange' ),
		'add_new_item'          => esc_html__( 'Add New Item', 'orange' ),
		'add_new'               => esc_html__( 'Add New', 'orange' ),
		'new_item'              => esc_html__( 'New Item', 'orange' ),
		'edit_item'             => esc_html__( 'Edit Item', 'orange' ),
		'update_item'           => esc_html__( 'Update Item', 'orange' ),
		'view_item'             => esc_html__( 'View Item', 'orange' ),
		'view_items'            => esc_html__( 'View Items', 'orange' ),
		'search_items'          => esc_html__( 'Search Item', 'orange' ),
		'not_found'             => esc_html__( 'Not found', 'orange' ),
		'not_found_in_trash'    => esc_html__( 'Not found in Trash', 'orange' ),
		'featured_image'        => esc_html__( 'Work Image', 'orange' ),
		'set_featured_image'    => esc_html__( 'Set work image', 'orange' ),
		'remove_featured_image' => esc_html__( 'Remove featured image', 'orange' ),
		'use_featured_image'    => esc_html__( 'Use as featured image', 'orange' ),
		'insert_into_item'      => esc_html__( 'Insert into item', 'orange' ),
		'uploaded_to_this_item' => esc_html__( 'Uploaded to this item', 'orange' ),
		'items_list'            => esc_html__( 'Items list', 'orange' ),
		'items_list_navigation' => esc_html__( 'Items list navigation', 'orange' ),
		'filter_items_list'     => esc_html__( 'Filter items list', 'orange' ),
	);
	$args = array(
		'label'                 => esc_html__( 'Project', 'orange' ),
		'description'           => esc_html__( 'Post Type Description', 'orange' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor', 'thumbnail' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'   => 'dashicons-book',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
	);
	register_post_type( 'project', $args );

}
add_action( 'init', 'orange_project', 0 );

}

if ( ! function_exists('orange_work') ) {

// Register Work
function orange_work() {

	$labels = array(
		'name'                  => esc_html_x( 'Works', 'Post Type General Name', 'orange' ),
		'singular_name'         => esc_html_x( 'Work', 'Post Type Singular Name', 'orange' ),
		'menu_name'             => esc_html__( 'Works', 'orange' ),
		'name_admin_bar'        => esc_html__( 'Works', 'orange' ),
		'archives'              => esc_html__( 'Item Archives', 'orange' ),
		'attributes'            => esc_html__( 'Item Attributes', 'orange' ),
		'parent_item_colon'     => esc_html__( 'Parent Item:', 'orange' ),
		'all_items'             => esc_html__( 'All Items', 'orange' ),
		'add_new_item'          => esc_html__( 'Add New Item', 'orange' ),
		'add_new'               => esc_html__( 'Add New', 'orange' ),
		'new_item'              => esc_html__( 'New Item', 'orange' ),
		'edit_item'             => esc_html__( 'Edit Item', 'orange' ),
		'update_item'           => esc_html__( 'Update Item', 'orange' ),
		'view_item'             => esc_html__( 'View Item', 'orange' ),
		'view_items'            => esc_html__( 'View Items', 'orange' ),
		'search_items'          => esc_html__( 'Search Item', 'orange' ),
		'not_found'             => esc_html__( 'Not found', 'orange' ),
		'not_found_in_trash'    => esc_html__( 'Not found in Trash', 'orange' ),
		'featured_image'        => esc_html__( 'Work Image', 'orange' ),
		'set_featured_image'    => esc_html__( 'Set work image', 'orange' ),
		'remove_featured_image' => esc_html__( 'Remove featured image', 'orange' ),
		'use_featured_image'    => esc_html__( 'Use as featured image', 'orange' ),
		'insert_into_item'      => esc_html__( 'Insert into item', 'orange' ),
		'uploaded_to_this_item' => esc_html__( 'Uploaded to this item', 'orange' ),
		'items_list'            => esc_html__( 'Items list', 'orange' ),
		'items_list_navigation' => esc_html__( 'Items list navigation', 'orange' ),
		'filter_items_list'     => esc_html__( 'Filter items list', 'orange' ),
	);
	$args = array(
		'label'                 => esc_html__( 'Work', 'orange' ),
		'description'           => esc_html__( 'Post Type Description', 'orange' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'thumbnail' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'   => 'dashicons-portfolio',
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
	);
	register_post_type( 'work', $args );

}
add_action( 'init', 'orange_work', 0 );

}

if ( ! function_exists( 'orange_work_cat' ) ) {

// Register Custom Taxonomy
function orange_work_cat() {

	$labels = array(
		'name'                       => esc_html_x( 'Categories', 'Taxonomy General Name', 'orange' ),
		'singular_name'              => esc_html_x( 'Category', 'Taxonomy Singular Name', 'orange' ),
		'menu_name'                  => esc_html__( 'Category', 'orange' ),
		'all_items'                  => esc_html__( 'All Items', 'orange' ),
		'parent_item'                => esc_html__( 'Parent Item', 'orange' ),
		'parent_item_colon'          => esc_html__( 'Parent Item:', 'orange' ),
		'new_item_name'              => esc_html__( 'New Item Name', 'orange' ),
		'add_new_item'               => esc_html__( 'Add New Item', 'orange' ),
		'edit_item'                  => esc_html__( 'Edit Item', 'orange' ),
		'update_item'                => esc_html__( 'Update Item', 'orange' ),
		'view_item'                  => esc_html__( 'View Item', 'orange' ),
		'separate_items_with_commas' => esc_html__( 'Separate items with commas', 'orange' ),
		'add_or_remove_items'        => esc_html__( 'Add or remove items', 'orange' ),
		'choose_from_most_used'      => esc_html__( 'Choose from the most used', 'orange' ),
		'popular_items'              => esc_html__( 'Popular Items', 'orange' ),
		'search_items'               => esc_html__( 'Search Items', 'orange' ),
		'not_found'                  => esc_html__( 'Not Found', 'orange' ),
		'no_terms'                   => esc_html__( 'No items', 'orange' ),
		'items_list'                 => esc_html__( 'Items list', 'orange' ),
		'items_list_navigation'      => esc_html__( 'Items list navigation', 'orange' ),
	);
	$args = array(
		'labels'                     => $labels,
		'hierarchical'               => true,
		'public'                     => true,
		'show_ui'                    => true,
		'show_admin_column'          => true,
		'show_in_nav_menus'          => true,
		'show_tagcloud'              => true,
	);
	register_taxonomy( 'work_cat', array( 'work' ), $args );

}
add_action( 'init', 'orange_work_cat', 0 );

}

if ( ! function_exists('orange_testimonials') ) {

// Register Testimonials
function orange_testimonials() {

	$labels = array(
		'name'                  => esc_html_x( 'Testimonials', 'Post Type General Name', 'orange' ),
		'singular_name'         => esc_html_x( 'Testimonial', 'Post Type Singular Name', 'orange' ),
		'menu_name'             => esc_html__( 'Testimonials', 'orange' ),
		'name_admin_bar'        => esc_html__( 'Testimonials', 'orange' ),
		'archives'              => esc_html__( 'Item Archives', 'orange' ),
		'attributes'            => esc_html__( 'Item Attributes', 'orange' ),
		'parent_item_colon'     => esc_html__( 'Parent Item:', 'orange' ),
		'all_items'             => esc_html__( 'All Items', 'orange' ),
		'add_new_item'          => esc_html__( 'Add New Item', 'orange' ),
		'add_new'               => esc_html__( 'Add New', 'orange' ),
		'new_item'              => esc_html__( 'New Item', 'orange' ),
		'edit_item'             => esc_html__( 'Edit Item', 'orange' ),
		'update_item'           => esc_html__( 'Update Item', 'orange' ),
		'view_item'             => esc_html__( 'View Item', 'orange' ),
		'view_items'            => esc_html__( 'View Items', 'orange' ),
		'search_items'          => esc_html__( 'Search Item', 'orange' ),
		'not_found'             => esc_html__( 'Not found', 'orange' ),
		'not_found_in_trash'    => esc_html__( 'Not found in Trash', 'orange' ),
		'featured_image'        => esc_html__( 'Featured Image', 'orange' ),
		'set_featured_image'    => esc_html__( 'Set featured image', 'orange' ),
		'remove_featured_image' => esc_html__( 'Remove featured image', 'orange' ),
		'use_featured_image'    => esc_html__( 'Use as featured image', 'orange' ),
		'insert_into_item'      => esc_html__( 'Insert into item', 'orange' ),
		'uploaded_to_this_item' => esc_html__( 'Uploaded to this item', 'orange' ),
		'items_list'            => esc_html__( 'Items list', 'orange' ),
		'items_list_navigation' => esc_html__( 'Items list navigation', 'orange' ),
		'filter_items_list'     => esc_html__( 'Filter items list', 'orange' ),
	);
	$args = array(
		'label'                 => esc_html__( 'Testimonial', 'orange' ),
		'description'           => esc_html__( 'Post Type Description', 'orange' ),
		'labels'                => $labels,
		'supports'              => array( 'title', 'editor' , 'thumbnail' ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'   => 'dashicons-format-quote',		
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
	);
	register_post_type( 'testimonials', $args );

}
add_action( 'init', 'orange_testimonials', 0 );

}


if ( ! function_exists('orange_pricing') ) {

// Register Pricing Table
function orange_pricing() {

	$labels = array(
		'name'                  => esc_html_x( 'Pricing Table', 'Post Type General Name', 'orange' ),
		'singular_name'         => esc_html_x( 'Pricing Table', 'Post Type Singular Name', 'orange' ),
		'menu_name'             => esc_html__( 'Pricing Table', 'orange' ),
		'name_admin_bar'        => esc_html__( 'Pricing Table', 'orange' ),
		'archives'              => esc_html__( 'Item Archives', 'orange' ),
		'attributes'            => esc_html__( 'Item Attributes', 'orange' ),
		'parent_item_colon'     => esc_html__( 'Parent Item:', 'orange' ),
		'all_items'             => esc_html__( 'All Items', 'orange' ),
		'add_new_item'          => esc_html__( 'Add New Item', 'orange' ),
		'add_new'               => esc_html__( 'Add New', 'orange' ),
		'new_item'              => esc_html__( 'New Item', 'orange' ),
		'edit_item'             => esc_html__( 'Edit Item', 'orange' ),
		'update_item'           => esc_html__( 'Update Item', 'orange' ),
		'view_item'             => esc_html__( 'View Item', 'orange' ),
		'view_items'            => esc_html__( 'View Items', 'orange' ),
		'search_items'          => esc_html__( 'Search Item', 'orange' ),
		'not_found'             => esc_html__( 'Not found', 'orange' ),
		'not_found_in_trash'    => esc_html__( 'Not found in Trash', 'orange' ),
		'featured_image'        => esc_html__( 'Featured Image', 'orange' ),
		'set_featured_image'    => esc_html__( 'Set featured image', 'orange' ),
		'remove_featured_image' => esc_html__( 'Remove featured image', 'orange' ),
		'use_featured_image'    => esc_html__( 'Use as featured image', 'orange' ),
		'insert_into_item'      => esc_html__( 'Insert into item', 'orange' ),
		'uploaded_to_this_item' => esc_html__( 'Uploaded to this item', 'orange' ),
		'items_list'            => esc_html__( 'Items list', 'orange' ),
		'items_list_navigation' => esc_html__( 'Items list navigation', 'orange' ),
		'filter_items_list'     => esc_html__( 'Filter items list', 'orange' ),
	);
	$args = array(
		'label'                 => esc_html__( 'Pricing Table', 'orange' ),
		'description'           => esc_html__( 'Post Type Description', 'orange' ),
		'labels'                => $labels,
		'supports'              => array( 'title',  ),
		'hierarchical'          => false,
		'public'                => true,
		'show_ui'               => true,
		'show_in_menu'          => true,
		'menu_position'         => 5,
		'menu_icon'   => 'dashicons-list-view',	
		'show_in_admin_bar'     => true,
		'show_in_nav_menus'     => true,
		'can_export'            => true,
		'has_archive'           => true,
		'exclude_from_search'   => false,
		'publicly_queryable'    => true,
		'capability_type'       => 'page',
	);
	register_post_type( 'pricing', $args );

}
add_action( 'init', 'orange_pricing', 0 );

}