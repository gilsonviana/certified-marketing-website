<?php

/*

Plugin Name: Orange Plugin

Plugin URI: http://themesvila.com

Description: After install the orange WordPress Theme, you must need to install this "orange Plugin" first to get all functions of orange WP Theme.

Author: Masum Billah

Author URI: http://themesvila.com

Version: 1.0

Text Domain: orange

*/


//define

define( 'ORANGEPLUGINDIR', dirname( __FILE__ ) ); 


// Add main files

include_once(ORANGEPLUGINDIR. '/inc/custom_posts.php');
include_once(ORANGEPLUGINDIR. '/inc/shortcodes.php');
include_once(ORANGEPLUGINDIR. '/inc/orange_metabox.php');
include_once(ORANGEPLUGINDIR. '/inc/theme-options.php');
include_once(ORANGEPLUGINDIR. '/inc/custom_css.php');

include_once(ORANGEPLUGINDIR.'/inc/kc_extend/extend_kc.php');  



// Enable shortcodes in text widgets
add_filter('widget_text','do_shortcode');